import { NextRequest, NextResponse } from 'next/server';

// Retry helper with exponential backoff
async function callGeminiWithRetry(prompt: string, maxRetries = 3) {
  for (let attempt = 1; attempt <= maxRetries; attempt++) {
    try {
      const response = await fetch(
        'https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent',
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'x-goog-api-key': process.env.GEMINI_API_KEY!
          },
          body: JSON.stringify({
            contents: [{ parts: [{ text: prompt }] }],
            generationConfig: {
              temperature: 0.5,
              maxOutputTokens: 4096
            }
          })
        }
      );

      if (response.status === 429) {
        if (attempt < maxRetries) {
          const waitTime = Math.pow(2, attempt) * 1000; // 2s, 4s, 8s
          console.log(`⏳ Rate limit hit. Retrying in ${waitTime}ms... (${attempt}/${maxRetries})`);
          await new Promise(resolve => setTimeout(resolve, waitTime));
          continue;
        }
        throw new Error('Rate limit exceeded after retries. Wait 60 seconds.');
      }

      if (!response.ok) {
        throw new Error(`API error: ${response.status}`);
      }

      return await response.json();

    } catch (error: any) {
      if (attempt === maxRetries) {
        throw error;
      }
      await new Promise(resolve => setTimeout(resolve, 1000 * attempt));
    }
  }
}

export async function POST(request: NextRequest) {
  try {
    const { files, docTypes, style } = await request.json();

    if (!files || files.length === 0) {
      return NextResponse.json(
        { error: 'No files provided' },
        { status: 400 }
      );
    }

    if (!docTypes || docTypes.length === 0) {
      return NextResponse.json(
        { error: 'No documentation types selected' },
        { status: 400 }
      );
    }

    console.log(`📝 Generating ${docTypes.join(', ')} docs...`);

    // Build concise prompt
    const prompt = `Generate documentation for this project.

FILES: ${files.slice(0, 5).map((f: any) => f.name || f.path).join(', ')} (${files.length} total)

STYLE: ${style || 'technical'}

GENERATE: ${docTypes.join(', ')}

Return ONLY this JSON (no markdown):
{
  ${docTypes.includes('readme') ? '"readme": "# Project\\n\\n## Description\\nFull content here...",' : ''}
  ${docTypes.includes('apiDocs') ? '"apiDocs": "# API Documentation\\n\\nFull content here...",' : ''}
  ${docTypes.includes('deployment') ? '"deployment": "# Deployment Guide\\n\\nFull content here...",' : ''}
  ${docTypes.includes('contributing') ? '"contributing": "# Contributing\\n\\nFull content here..."' : ''}
}

${docTypes.includes('readme') ? `
README must include:
- Project title and description
- Installation steps (npm install)
- Usage instructions (npm run dev)
- Tech stack
- Features list
` : ''}

${docTypes.includes('apiDocs') ? `
API DOCS must include:
- Base URL
- Auth method
- Each endpoint: method, path, request, response, example
` : ''}

${docTypes.includes('deployment') ? `
DEPLOYMENT must include:
- Prerequisites
- Environment variables
- Docker setup (if applicable)
- Vercel/Railway deployment steps
` : ''}

Keep documentation concise and practical. Use markdown format. Return ONLY JSON.`;

    // Call with retry logic
    const data = await callGeminiWithRetry(prompt);
    
    if (!data.candidates?.[0]?.content?.parts?.[0]?.text) {
      return NextResponse.json(
        { error: 'No response from AI' },
        { status: 500 }
      );
    }

    const text = data.candidates[0].content.parts[0].text;
    console.log('Response length:', text.length);

    // Parse JSON
    let parsed;
    try {
      let cleaned = text.trim();
      cleaned = cleaned.replace(/```json\s*/gi, '').replace(/```\s*/g, '');
      
      const start = cleaned.indexOf('{');
      const end = cleaned.lastIndexOf('}');
      
      if (start === -1 || end === -1) {
        throw new Error('No JSON found');
      }
      
      cleaned = cleaned.substring(start, end + 1);
      parsed = JSON.parse(cleaned);
      
    } catch (parseError: any) {
      console.error('Parse error:', parseError.message);
      return NextResponse.json({
        error: 'Failed to parse AI response',
        details: parseError.message,
        sample: text.substring(0, 500)
      }, { status: 500 });
    }

    // Validate at least one doc was generated
    const generatedDocs = Object.keys(parsed).filter(key => 
      ['readme', 'apiDocs', 'deployment', 'contributing'].includes(key)
    );

    if (generatedDocs.length === 0) {
      return NextResponse.json({
        error: 'No documentation generated',
        received: Object.keys(parsed)
      }, { status: 500 });
    }

    console.log(`✅ Generated: ${generatedDocs.join(', ')}`);

    return NextResponse.json({
      success: true,
      docs: parsed
    });

  } catch (error: any) {
    console.error('Generate docs error:', error);
    
    if (error.message.includes('Rate limit')) {
      return NextResponse.json({
        error: 'Rate limit exceeded. Please wait 60 seconds and try again.',
        hint: 'Too many requests to Gemini API. Try again in 1 minute.'
      }, { status: 429 });
    }
    
    return NextResponse.json({
      error: error.message || 'Failed to generate documentation'
    }, { status: 500 });
  }
}
